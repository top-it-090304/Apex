extends Area2D

var flag_id: String = ""
var flag = false

func _ready() -> void:
	$AnimatedSprite2D.play()

func _on_body_entered(_body: Node2D) -> void:
	if flag == false:
		Events.TOUCHING_THE_FLAG.emit($AnimatedSprite2D)
		var loaded0 = SaveManager.load_slot(SaveManager.slot_save)
		loaded0["level"]["flags_collected"] = loaded0["level"]["flags_collected"] + 1
		SaveManager.save_slot(SaveManager.slot_save, loaded0)
		flag = true
